﻿#ifndef CGLOBALDATA_H
#define CGLOBALDATA_H

#include <QObject>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QDebug>

class CGlobalData : public QWidget
{
    Q_OBJECT
    explicit CGlobalData(QWidget *parent = nullptr);
public:
    static CGlobalData &getInstance();

    // 添加用户
    bool insertUserData(const QString &usr, const QString &password);

    // 判断用户是否存在
    bool judgeUserExist(const QString &user);

    // 判断用户信息是否正确
    bool judgeUserInfo(const QString &user, const QString &password);

    QSqlDatabase getSqliteDB() const;

private:
    QSqlDatabase    m_sqliteDB;
};

#endif // CGLOBALDATA_H
