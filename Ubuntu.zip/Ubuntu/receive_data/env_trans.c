/*===============================================
*   文件名称：test02.c
*   创 建 者：     
*   创建日期：2025年03月05日
*   描    述：
================================================*/
#include <stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<string.h>
#include<unistd.h>
#include "serial.h"
#include <stdio.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  //UNIX标准函数定义
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h> //文件控制定义
#include <termios.h>  //PPSIX终端控制定义
#include <errno.h>    //错误号定义
#include <pthread.h>



int serial_init()
{
    int fd = open("/dev/ttyUSB0", O_RDWR|O_NOCTTY);
    if(-1 == fd)
    {
        perror("open serial");
        return -1;
    }

    struct termios options = {0};
    if(tcgetattr( fd,&options)  !=  0)
    {
        perror("SetupSerial");
        return -1;
    }
    cfsetispeed(&options, B115200);		//输出波特率
    cfsetospeed(&options, B115200);		//输入波特率

    options.c_cflag |= CLOCAL|CREAD;  	//忽略modem控制线，使能接收
    options.c_cflag |= CS8;				//8位数据位
    options.c_cflag &= ~CRTSCTS;		//禁用硬件流控
    options.c_cflag &= ~PARENB; 		//清除校验位 PARODD
    options.c_cflag &= ~CSTOPB; 		//一位停止位

    options.c_oflag &= ~(ONLCR | OCRNL);
    options.c_oflag &= ~(ONLCR | OCRNL | ONOCR | ONLRET); //将输出的回车转化成换行

    options.c_iflag &= ~(IXON | IXOFF | IXANY); //禁用流控
    options.c_iflag &= ~(INLCR | ICRNL | IGNCR);//将输入的回车转化成换行
    options.c_iflag &= ~(BRKINT | INPCK | ISTRIP);//ICRNL 将输入的回车转化成换行（如果IGNCR未设置的情况下）
    options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);//禁用终端回显等

    options.c_cc[VTIME] = 1; /* 读取一个字符等待0*(0/10)s */
    options.c_cc[VMIN] = 1; /* 读取字符的最少个数为0 */

    tcflush(fd,TCIFLUSH);
    if (tcsetattr(fd,TCSANOW,&options) != 0)
    {
        perror("com set error!");
        return -1;
    }
    return fd;
}

int serial_send(int fd, unsigned char *buf, int count)
{
    int ret;
    int total = 0;
    while (total != count) 
    {
        ret = write(fd, buf + total, count - total);
        if (ret == -1) 
        {
            perror("serial_send");
            break;
        } else
            total += ret;
    }	
    return total;
}

int serial_recv(int fd, char *buf, int count,int len_buf)
{
    int ret;
    int total = 0;	
    while (total != count) 
    {
        ret = read(fd, buf + total, count - total);
        if (ret == -1)
        {
            perror("serial_recv");
            break;
        } 
        else if (ret == 0) 
        {
            fprintf(stdout, "serial->recv: timeout or end-of-file\n");
            break;
        } else
            total += ret;
    }
    int i = 0;
    for (i = 0; i < len_buf; i++)
    {
        printf("%.2x ", buf[i]);
    }
    printf("\n");
    return total;
}

int serial_exit(int fd)
{
    if (close(fd)) {
        perror("serial->exit");
        return -1;
    }
    return 0;
}

int switch_function(int choice){
    // printf("choice1111 = %d\n", choice);
    // choice = choice-48;
    int fd = serial_init();
    if(fd == -1)
    {
        printf("serial_init error\n");
        return -1;
    }
    
    // unsigned char buf[36] = {0xdd, 0x07, 0x24, 0x00};
    printf("choice = %d\n", choice);
    unsigned char buf[36] = {0}; // 初始化所有元素为0

        if(choice == 0){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x00;//00 -- 开灯
    }else if(choice == 1){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x01;//01 -- 关灯
    }else if(choice == 2){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x02;//02 -- 开蜂鸣器
    }else if(choice == 3){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x03;//03 -- 关蜂鸣器
    }else if(choice == 4){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x04;//04 -- 开风扇        
    }else if(choice == 5){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x05;//05 -- 风扇低速       
    }else if(choice == 6){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x06;//06 -- 风扇中速      
    }else if(choice == 7){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x07;//07 -- 风扇高速     
    }else if(choice == 8){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x08;//08 -- 关风扇      
    }else if(choice == 9){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x09;//09 -- 开数码管
    }else if(choice == 10){
        buf[0] = 0xdd; buf[1] = 0x04; buf[2] = 0x24; buf[3] = 0x00; buf[4] = 0x0a;//0a -- 关数码管
    }
serial_recv(fd, NULL,0,0);

    int flag = serial_send(fd, buf, 36);
    if(flag==-1)
    {
        printf("serial_send error\n");
        return -1;
    }
    serial_recv(fd, NULL,0,0);
    serial_exit(fd);
    // printf("正常退出\n");
    return 0;
}


char* hex_array_to_string(unsigned char *hex_array, int len) {
    // 计算最终字符串的最大长度
    // 每个字节需要2位表示 + 1个空格（最后一个不需要空格），再加上结尾的'\0'
    int str_len = len * 3 - 1;
    char *result = (char *)malloc(str_len + 1); // +1 for null terminator
    if (result == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return NULL;
    }

    // 使用sprintf逐个格式化并拼接
    char *ptr = result;
    for (int i = 0; i < len; i++) {
        ptr += sprintf(ptr, "%.2x", hex_array[i]);
        if (i < len - 1) {
            *(ptr++) = ' '; // 添加空格
        }
    }
    *ptr = '\0'; // 结尾的null字符

    return result;
}



int main(int argc, char *argv[])
{ 
    //1. create socket
    //
    int socketfd = socket(AF_INET,SOCK_STREAM,0);
    if(-1 == socketfd){
        perror("socket");
        return -1;
    }
    //printf("socket successful!\n");
    
    //2. bind ip and port
    struct sockaddr_in addr;//create addr
    addr.sin_family = AF_INET;
    addr.sin_port =htons(8880);//端口转字节序
    addr.sin_addr.s_addr = inet_addr("0.0.0.0");

    //set port reuse
    int opt_val = 1;
    setsockopt(socketfd,SOL_SOCKET,SO_REUSEADDR,&opt_val,sizeof(int));

    if(-1 == bind(socketfd,(struct sockaddr *)&addr,sizeof(addr)))
    {
        perror("bind");
        return -1;

    }
    //printf("bind successful!\n");

    //3. listen
    if(-1 == listen(socketfd,4)){
        perror("listen");
        return -1;
    }

    while(1){
    	//4. accept
	    struct sockaddr_in c_addr;
	    socklen_t length=sizeof(c_addr);

	   int connfd = accept(socketfd,(struct sockaddr *)&c_addr,&length);
	   // if you do not wanna receive any message, you can set last two parameter as NULL
	   // int connfd = accept(socketfd,NULL,NULL);

	   if(-1 == connfd){

		perror("accept");
		return -1;
	   }
	   char *c_ip = inet_ntoa(c_addr.sin_addr);
	   unsigned short c_port = ntohs(c_addr.sin_port); 


	   printf("Client ip : %s\n",c_ip);
	   printf("Client port : %hu\n",c_port);

       int fd = serial_init();
        if(fd == -1)
        {
            printf("serial_init error\n");
            return -1;
        }

        unsigned char buf[36];
        int count = 36;
        int len_buf = sizeof(buf); 
        char *result_str=NULL;
        while(1){
            int flag = serial_recv(fd, buf, count, len_buf);
            int len = sizeof(buf) / sizeof(buf[0]);

            result_str = hex_array_to_string(buf, len);
            if (result_str != NULL) {
                // write(socketfd, result_str, strlen(result_str));
                write(connfd, result_str, strlen(result_str));
                printf("the string : %s\n",result_str);
                printf("the length : %ld\n",strlen(result_str));
            }

            if(flag == -1)
            {
                printf("serial_recv error\n");
                return -1;
            }
            memset(buf, 0, 36); // 将数组中的所有元素初始化为0
        }
        free(result_str);
        serial_exit(fd);
    }

    return 0;
}
