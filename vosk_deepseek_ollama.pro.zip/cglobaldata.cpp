﻿#include "cglobaldata.h"

#include <QSqlQuery>
#include <QSqlError>
#include <QDateTime>

CGlobalData::CGlobalData(QWidget *parent) : QWidget(parent)
{
    // 指定数据库类型
    m_sqliteDB = QSqlDatabase::addDatabase("QSQLITE");
    // 指定数据库  "./data.db"
    m_sqliteDB.setDatabaseName("D:/QT/qt/projects/deepseek_vosk/data.db");//"D:\QT\qt\projects\deepseek_vosk\data.db"
    if(!m_sqliteDB.open())
    {
        QMessageBox::information(this, u8"提示", u8"数据库打开失败");
        return;
    }
}

CGlobalData &CGlobalData::getInstance()
{
    static CGlobalData instance;
    return instance;
}

bool CGlobalData::insertUserData(const QString &user, const QString &password)
{
    QString sql = QString(R"(INSERT INTO UserInfo("user", password) VALUES('%1', '%2');)").arg(user, password);
    QSqlQuery query;
    if(query.exec(sql)) {
        QMessageBox::information(this, u8"提示", u8"注册成功！");
        return true;
    }
    else {
        QMessageBox::information(this, u8"提示", u8"添加用户失败 " + query.lastError().text());
    }

    return false;
}

bool CGlobalData::judgeUserExist(const QString &user)
{
    QString sql = QString("SELECT * FROM UserInfo WHERE user = '%1';").arg(user);
    qDebug() << sql;
    QSqlQuery query;
    if(query.exec(sql)) {
        qDebug() << query.value(0) << query.value(1) << query.value(2);
        return query.next();
    }
    QMessageBox::information(this, u8"提示", u8"用户是否存在校验失败 " + query.lastError().text());

    return false;
}

bool CGlobalData::judgeUserInfo(const QString &user, const QString &password)
{
    QString sql = QString("SELECT * FROM UserInfo WHERE user = '%1' and password = '%2';").arg(user, password);
    QSqlQuery query;
    if(query.exec(sql)) {
        return query.next();
    }
    QMessageBox::information(this, u8"提示", u8"用户信息校验失败 "  + query.lastError().text());

    return false;

}

QSqlDatabase CGlobalData::getSqliteDB() const
{
    return m_sqliteDB;
}
