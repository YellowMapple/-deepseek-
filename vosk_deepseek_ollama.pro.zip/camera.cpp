#include "camera.h"
#include "ui_camera.h"

camera::camera(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::camera)
{
    ui->setupUi(this);

    // 初始化UDP socket
    socket = new QUdpSocket(this);
    connect(socket, &QUdpSocket::readyRead, this, &camera::readPendingDatagrams);

    // 初始化心跳定时器
    heartbeatTimer = new QTimer(this);
    connect(heartbeatTimer, &QTimer::timeout, this, &camera::sendHeartbeat);

    // 连接按钮信号
    connect(ui->connectButton, &QPushButton::clicked, this, &camera::connectToServer);

    // 设置默认IP地址
//    ui->serverAddressEdit->setText("192.168.186.149");

    //绑定socket
    // 对象空间分配
    socket02 = new QTcpSocket();

    connect(socket02,&QTcpSocket::readyRead,this,camera::on_readyRead);//绑定接收摄像头数据


}

camera::~camera()
{
    if (socket->isOpen()) {
        socket->close();
    }
    delete ui;
}

//QString parseAndPrintData(QString& receiverText) {


//    return output;
//}


void camera::on_readyRead(){
    if(socket02->bytesAvailable()<107){
        return;//等待接收到36个字节
    }

    char buf[108];
    memset(buf,0,107);
    buf[108] = '\0';

    socket02->read(buf,107);

    QString receiverText = QString::fromLatin1(buf,107);
    qDebug() << "Receiver Text:" << receiverText;

    // 这里执行转换
    QByteArray data = QByteArray::fromHex(receiverText.toLatin1());

    // 解析数据包并构建输出字符串
    QString output;

    // Tag
    output += QString("Tag: %1\n").arg(QString("%1").arg(static_cast<unsigned char>(data[0]), 2, 16, QChar('0')).toUpper());

    // ID
    output += QString("ID: %1\n").arg(QString("%1").arg(static_cast<unsigned char>(data[1]), 2, 16, QChar('0')).toUpper());

    // Length
    output += QString("Length: %1\n").arg(QString("%1").arg(static_cast<unsigned char>(data[2]), 2, 16, QChar('0')).toUpper());

    // 温度
    int tempDecimal = static_cast<unsigned char>(data[4]);
    int tempInteger = static_cast<unsigned char>(data[5]);
    float temperature = tempInteger + tempDecimal / 10.0f;
    output += QString("Temperature: %1\n").arg(temperature);
    qDebug() << "Temperature:" << temperature;



    // 湿度
    int humidity = static_cast<unsigned char>(data[7]);
    output += QString("Humidity: %1\n").arg(humidity);
    qDebug() << "Humidity:" << humidity;

    // 加速度
    int accX = static_cast<signed char>(data[8]);
    int accY = static_cast<signed char>(data[9]);
    int accZ = static_cast<signed char>(data[10]);
    output += QString("Acceleration X: %1\n").arg(accX);
    output += QString("Acceleration Y: %1\n").arg(accY);
    output += QString("Acceleration Z: %1\n").arg(accZ);

    qDebug() << "Acceleration X:" << accX;
    qDebug() << "Acceleration Y:" << accY;
    qDebug() << "Acceleration Z:" << accZ;

    // ADC数据
    int adcCh0 = (static_cast<unsigned char>(data[15]) << 8) | static_cast<unsigned char>(data[15]);
    int adcCh1 = (static_cast<unsigned char>(data[17]) << 8) | static_cast<unsigned char>(data[17]);
    output += QString("ADC Channel 0: %1\n").arg(adcCh0);
    output += QString("ADC Channel 1: %1\n").arg(adcCh1);
    qDebug() << "ADC Channel 0:" << adcCh0;
    qDebug() << "ADC Channel 1:" << adcCh1;

    // 光照强度
    int light = (static_cast<unsigned char>(data[20]));
    output += QString("Light Intensity: %1\n").arg(light);
    qDebug() << "Light Intensity:" << light;

    // 状态信息
    int led = static_cast<unsigned char>(data[24]);
    int fan = static_cast<unsigned char>(data[25]);
    int buzz = static_cast<unsigned char>(data[26]);
    int sevenLed = static_cast<unsigned char>(data[27]);
    output += QString("LED Status: %1\n").arg(led);
    output += QString("Fan Status: %1\n").arg(fan);
    output += QString("Buzz Status: %1\n").arg(buzz);
    qDebug() << "LED Status:" << led;
    qDebug() << "Fan Status:" << fan;
    qDebug() << "Buzz Status:" << buzz;
    qDebug() << "Seven Segment LED Status:" << sevenLed;

    output += QString("Seven Segment LED Status: %1\n").arg(sevenLed);
    ui->env_information->setText(output);
//    parseAndPrintData(receiverText);
}

void camera::connectToServer()
{
    serverAddress = QString("192.168.186.149");
    if (serverAddress.isEmpty()) {
        QMessageBox::warning(this, "错误", "请输入服务器IP地址");
        return;
    }

    serverPort = 8080;  // 使用与服务器相同的端口

    // 绑定任意端口
    QHostAddress anyAddress(QHostAddress::Any);
    if (!socket->bind(anyAddress, quint16(0))) {
        QMessageBox::critical(this, "错误", "无法绑定UDP端口");
        return;
    }

    // 开始发送心跳包
    heartbeatTimer->start(1000);  // 每秒发送一次
    sendHeartbeat();  // 立即发送第一个心跳包

    // 更新UI状态
    ui->connectButton->setEnabled(false);
//    ui->serverAddressEdit->setEnabled(false);
//    ui->statusbar->showMessage("已连接到服务器");

    //连接远程主机
    QString ip = QString("192.168.186.149");
    unsigned short port = 8880;
//    QString ip = QString("192.168.88.1");
//    unsigned short port = 8888;
    socket02->connectToHost(ip,port);
//    qDebug()<<"成功与服务器连接！";
    //只调用一次connected
    connect(socket02,&QTcpSocket::connected,this,[]{
        qDebug()<<"环境端口成功与服务器连接！";
    });
}

void camera::sendHeartbeat()
{
    QByteArray heartbeat = "HELLO";
    socket->writeDatagram(heartbeat, QHostAddress(serverAddress), serverPort);
}

void camera::readPendingDatagrams()
{
    while (socket->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(socket->pendingDatagramSize());
        socket->readDatagram(datagram.data(), datagram.size());

        if (waitingForParams) {
            if (datagram.size() == sizeof(VideoParams)) {
                VideoParams params;
                memcpy(&params, datagram.data(), sizeof(VideoParams));
                processVideoParams(params);
                waitingForParams = false;
            }
        } else {
            processVideoFrame(datagram);
            waitingForParams = true;
        }
    }
}

void camera::processVideoParams(const VideoParams &params)
{
    currentParams = params;
}

void camera::processVideoFrame(const QByteArray &data)
{
    QImage image;

    if (currentParams.format == 0) {  // YUYV
        // 转换YUYV到RGB
        QByteArray rgbData;
        rgbData.resize(currentParams.width * currentParams.height * 3);

        const uchar *yuyv = reinterpret_cast<const uchar*>(data.constData());
        uchar *rgb = reinterpret_cast<uchar*>(rgbData.data());

        for (unsigned int i = 0; i < currentParams.width * currentParams.height * 2; i += 4) {
            int y0 = yuyv[i];
            int u = yuyv[i + 1];
            int y1 = yuyv[i + 2];
            int v = yuyv[i + 3];

            // 第一个像素
            rgb[i/4*6] = qBound(0, (int)(y0 + 1.4075 * (v - 128)), 255);     // r
            rgb[i/4*6+1] = qBound(0, (int)(y0 - 0.3455 * (u - 128) - 0.7169 * (v - 128)), 255);  // g
            rgb[i/4*6+2] = qBound(0, (int)(y0 + 1.7790 * (u - 128)), 255);   // b

            // 第二个像素
            rgb[i/4*6+3] = qBound(0, (int)(y1 + 1.4075 * (v - 128)), 255);     // r
            rgb[i/4*6+4] = qBound(0, (int)(y1 - 0.3455 * (u - 128) - 0.7169 * (v - 128)), 255);  // g
            rgb[i/4*6+5] = qBound(0, (int)(y1 + 1.7790 * (u - 128)), 255);   // b
        }

        image = QImage(rgb, currentParams.width, currentParams.height, QImage::Format_RGB888);
    } else {  // MJPEG
        image.loadFromData(data, "JPEG");
    }

    if (!image.isNull()) {
        ui->imageLabel->setPixmap(QPixmap::fromImage(image).scaled(
            ui->imageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }

    // 更新状态栏显示FPS和分辨率
//    ui->statusbar->showMessage(QString("分辨率: %1x%2 - %3 FPS")
//                             .arg(currentParams.width)
//                             .arg(currentParams.height)
//                             .arg(currentParams.fps));
    ui->graph_information->setText(QString("width : %1\nheight : %2\nfps : %3 FPS")
                                   .arg(currentParams.width)  // 插入宽度
                                   .arg(currentParams.height) // 插入高度
                                   .arg(currentParams.fps));   // 插入帧率
}

//void camera::on_connectButton_2_clicked()
//{
//    this->hide();
//    emit back_to_mainwindow();//触发这个信号
//}

void camera::on_control_system_clicked()
{
    this->hide();
    emit back_to_mainwindow();//触发这个信号，返回到控制系统
}



void camera::on_back_to_login_clicked()
{
    this->hide();
    emit back_to_login();//返回登录页面
}


