#ifndef CAMERA_H
#define CAMERA_H

#include <QWidget>
#include <QUdpSocket>
#include <QTimer>
#include <QMessageBox>
#include <QTcpSocket>
#include <QString>
#include <QByteArray>
#include <QDebug>

namespace Ui {
class camera;
}

// 与服务器端相同的视频参数结构
struct VideoParams {
    unsigned int width;
    unsigned int height;
    unsigned int format;  // 0: YUYV, 1: MJPEG
    unsigned int fps;
};


class camera : public QWidget
{
    Q_OBJECT
signals:
    void back_to_mainwindow();//自定义信号
    void back_to_login();

public:
    explicit camera(QWidget *parent = nullptr);
    ~camera();
private slots:
    void connectToServer();
    void readPendingDatagrams();
    void sendHeartbeat();
    void on_readyRead();
//    QString parseAndPrintData(QString& receiverText);
//    void on_connectButton_2_clicked();

    void on_control_system_clicked();

    void on_back_to_login_clicked();

//    void on_connectButton_clicked();

private:
    void processVideoFrame(const QByteArray &data);
    void processVideoParams(const VideoParams &params);
    Ui::camera *ui;

    QUdpSocket *socket;
    QTimer *heartbeatTimer;
    QString serverAddress;
    quint16 serverPort;
    VideoParams currentParams;
    bool waitingForParams;
    QTcpSocket *socket02;

};

#endif // CAMERA_H
