/********************************************************************************
** Form generated from reading UI file 'camera.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CAMERA_H
#define UI_CAMERA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_camera
{
public:
    QPushButton *back_to_login;
    QLabel *imageLabel;
    QPushButton *connectButton;
    QTextEdit *env_information;
    QTextEdit *graph_information;
    QPushButton *control_system;
    QLabel *label;

    void setupUi(QWidget *camera)
    {
        if (camera->objectName().isEmpty())
            camera->setObjectName(QString::fromUtf8("camera"));
        camera->resize(1440, 740);
        camera->setMaximumSize(QSize(1710, 1098));
        back_to_login = new QPushButton(camera);
        back_to_login->setObjectName(QString::fromUtf8("back_to_login"));
        back_to_login->setGeometry(QRect(1210, 590, 200, 100));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font.setPointSize(16);
        back_to_login->setFont(font);
        imageLabel = new QLabel(camera);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
        imageLabel->setGeometry(QRect(30, 40, 901, 651));
        imageLabel->setMinimumSize(QSize(640, 480));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        imageLabel->setFont(font1);
        imageLabel->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        imageLabel->setAlignment(Qt::AlignCenter);
        connectButton = new QPushButton(camera);
        connectButton->setObjectName(QString::fromUtf8("connectButton"));
        connectButton->setGeometry(QRect(960, 590, 200, 100));
        connectButton->setFont(font);
        env_information = new QTextEdit(camera);
        env_information->setObjectName(QString::fromUtf8("env_information"));
        env_information->setGeometry(QRect(960, 40, 451, 311));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font2.setPointSize(10);
        font2.setKerning(false);
        env_information->setFont(font2);
        graph_information = new QTextEdit(camera);
        graph_information->setObjectName(QString::fromUtf8("graph_information"));
        graph_information->setGeometry(QRect(960, 390, 201, 161));
        graph_information->setFont(font);
        control_system = new QPushButton(camera);
        control_system->setObjectName(QString::fromUtf8("control_system"));
        control_system->setGeometry(QRect(1210, 390, 200, 161));
        control_system->setFont(font);
        label = new QLabel(camera);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, -10, 1500, 750));
        label->setFont(font1);
        label->setPixmap(QPixmap(QString::fromUtf8(":/new/res/graph/bg.jpg")));
        label->setScaledContents(true);
        label->raise();
        back_to_login->raise();
        imageLabel->raise();
        connectButton->raise();
        env_information->raise();
        graph_information->raise();
        control_system->raise();

        retranslateUi(camera);

        QMetaObject::connectSlotsByName(camera);
    } // setupUi

    void retranslateUi(QWidget *camera)
    {
        camera->setWindowTitle(QCoreApplication::translate("camera", "Form", nullptr));
        back_to_login->setText(QCoreApplication::translate("camera", "\351\200\200\345\207\272", nullptr));
        connectButton->setText(QCoreApplication::translate("camera", "\350\277\236\346\216\245\346\234\215\345\212\241\345\231\250", nullptr));
        env_information->setPlaceholderText(QCoreApplication::translate("camera", "\347\216\257\345\242\203\345\217\202\346\225\260", nullptr));
        graph_information->setPlaceholderText(QCoreApplication::translate("camera", "\346\221\204\345\203\217\345\244\264\345\217\202\346\225\260", nullptr));
        control_system->setText(QCoreApplication::translate("camera", "\346\216\247\345\210\266\347\263\273\347\273\237", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class camera: public Ui_camera {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CAMERA_H
