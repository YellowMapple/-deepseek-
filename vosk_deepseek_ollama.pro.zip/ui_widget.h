/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QTextEdit *textEdit_down;
    QPushButton *pushButton;
    QTextEdit *textEdit_up;
    QPushButton *pushButton_2;
    QPushButton *pushButton_camera;
    QPushButton *pushButton_light_on;
    QPushButton *pushButton_light_off;
    QPushButton *pushButton_6;
    QPushButton *pushButton_5;
    QPushButton *pushButton_4;
    QPushButton *pushButton_9;
    QPushButton *pushButton_12;
    QPushButton *pushButton_11;
    QPushButton *pushButton_10;
    QPushButton *pushButton_8;
    QPushButton *pushButton_7;
    QLabel *back_ground;
    QPushButton *pushButton_back_to_login;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1440, 740);
        textEdit_down = new QTextEdit(Widget);
        textEdit_down->setObjectName(QString::fromUtf8("textEdit_down"));
        textEdit_down->setEnabled(true);
        textEdit_down->setGeometry(QRect(20, 17, 851, 260));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(textEdit_down->sizePolicy().hasHeightForWidth());
        textEdit_down->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font.setPointSize(16);
        textEdit_down->setFont(font);
        textEdit_down->setMouseTracking(true);
        textEdit_down->setTabletTracking(true);
        textEdit_down->setFocusPolicy(Qt::NoFocus);
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 550, 400, 160));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy1);
        pushButton->setFont(font);
        textEdit_up = new QTextEdit(Widget);
        textEdit_up->setObjectName(QString::fromUtf8("textEdit_up"));
        textEdit_up->setGeometry(QRect(20, 283, 851, 259));
        sizePolicy.setHeightForWidth(textEdit_up->sizePolicy().hasHeightForWidth());
        textEdit_up->setSizePolicy(sizePolicy);
        textEdit_up->setFont(font);
        pushButton_2 = new QPushButton(Widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(470, 550, 400, 160));
        pushButton_2->setFont(font);
        pushButton_camera = new QPushButton(Widget);
        pushButton_camera->setObjectName(QString::fromUtf8("pushButton_camera"));
        pushButton_camera->setGeometry(QRect(890, 17, 341, 100));
        pushButton_camera->setFont(font);
        pushButton_light_on = new QPushButton(Widget);
        pushButton_light_on->setObjectName(QString::fromUtf8("pushButton_light_on"));
        pushButton_light_on->setGeometry(QRect(1260, 17, 150, 100));
        pushButton_light_on->setFont(font);
        pushButton_light_off = new QPushButton(Widget);
        pushButton_light_off->setObjectName(QString::fromUtf8("pushButton_light_off"));
        pushButton_light_off->setGeometry(QRect(1260, 170, 150, 100));
        pushButton_light_off->setFont(font);
        pushButton_6 = new QPushButton(Widget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(890, 460, 150, 100));
        pushButton_6->setFont(font);
        pushButton_5 = new QPushButton(Widget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(1080, 170, 150, 100));
        pushButton_5->setFont(font);
        pushButton_4 = new QPushButton(Widget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(890, 170, 150, 100));
        pushButton_4->setFont(font);
        pushButton_9 = new QPushButton(Widget);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(1260, 310, 150, 100));
        pushButton_9->setFont(font);
        pushButton_12 = new QPushButton(Widget);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setGeometry(QRect(890, 610, 150, 100));
        pushButton_12->setFont(font);
        pushButton_11 = new QPushButton(Widget);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(1260, 460, 150, 100));
        pushButton_11->setFont(font);
        pushButton_10 = new QPushButton(Widget);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(1080, 460, 150, 100));
        pushButton_10->setFont(font);
        pushButton_8 = new QPushButton(Widget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(1080, 310, 150, 100));
        pushButton_8->setFont(font);
        pushButton_7 = new QPushButton(Widget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(890, 310, 150, 100));
        pushButton_7->setFont(font);
        back_ground = new QLabel(Widget);
        back_ground->setObjectName(QString::fromUtf8("back_ground"));
        back_ground->setGeometry(QRect(0, 0, 1500, 750));
        back_ground->setFont(font);
        back_ground->setPixmap(QPixmap(QString::fromUtf8(":/new/res/graph/bg.jpg")));
        back_ground->setScaledContents(false);
        pushButton_back_to_login = new QPushButton(Widget);
        pushButton_back_to_login->setObjectName(QString::fromUtf8("pushButton_back_to_login"));
        pushButton_back_to_login->setGeometry(QRect(1079, 610, 331, 100));
        pushButton_back_to_login->setFont(font);
        back_ground->raise();
        textEdit_down->raise();
        pushButton->raise();
        textEdit_up->raise();
        pushButton_2->raise();
        pushButton_camera->raise();
        pushButton_light_on->raise();
        pushButton_light_off->raise();
        pushButton_6->raise();
        pushButton_5->raise();
        pushButton_4->raise();
        pushButton_9->raise();
        pushButton_12->raise();
        pushButton_11->raise();
        pushButton_10->raise();
        pushButton_8->raise();
        pushButton_7->raise();
        pushButton_back_to_login->raise();

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        textEdit_down->setHtml(QCoreApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'\345\256\213\344\275\223'; font-size:16pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'SimSun'; font-size:9pt;\"><br /></p></body></html>", nullptr));
        textEdit_down->setPlaceholderText(QCoreApplication::translate("Widget", "\350\276\223\345\207\272\346\226\207\346\234\254", nullptr));
        pushButton->setText(QCoreApplication::translate("Widget", "\345\275\225\351\237\263", nullptr));
        textEdit_up->setMarkdown(QString());
        textEdit_up->setHtml(QCoreApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'\345\256\213\344\275\223'; font-size:16pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'SimSun';\"><br /></p></body></html>", nullptr));
        textEdit_up->setPlaceholderText(QCoreApplication::translate("Widget", "\350\276\223\345\205\245\346\226\207\346\234\254", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Widget", "\345\217\221\351\200\201", nullptr));
        pushButton_camera->setText(QCoreApplication::translate("Widget", "\346\221\204\345\203\217\345\244\264\345\217\212\347\216\257\345\242\203\347\225\214\351\235\242", nullptr));
        pushButton_light_on->setText(QCoreApplication::translate("Widget", "\345\274\200\347\201\257", nullptr));
        pushButton_light_off->setText(QCoreApplication::translate("Widget", "\345\205\263\347\201\257", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Widget", "\345\274\200\351\243\216\346\211\207", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Widget", "\345\205\263\350\234\202\351\270\243\345\231\250", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Widget", "\345\274\200\350\234\202\351\270\243\345\231\250", nullptr));
        pushButton_9->setText(QCoreApplication::translate("Widget", "\351\243\216\346\211\207\351\253\230\351\200\237", nullptr));
        pushButton_12->setText(QCoreApplication::translate("Widget", "\345\205\263\346\225\260\347\240\201\347\256\241", nullptr));
        pushButton_11->setText(QCoreApplication::translate("Widget", "\345\274\200\346\225\260\347\240\201\347\256\241", nullptr));
        pushButton_10->setText(QCoreApplication::translate("Widget", "\345\205\263\351\243\216\346\211\207", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Widget", "\351\243\216\346\211\207\344\270\255\351\200\237", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Widget", "\351\243\216\346\211\207\344\275\216\351\200\237", nullptr));
        back_ground->setText(QString());
        pushButton_back_to_login->setText(QCoreApplication::translate("Widget", "\350\277\224\345\233\236\347\231\273\345\275\225\351\241\265\351\235\242", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
