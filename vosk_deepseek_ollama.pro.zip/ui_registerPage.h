/********************************************************************************
** Form generated from reading UI file 'registerPage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTERPAGE_H
#define UI_REGISTERPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_registerPage
{
public:
    QLabel *background;
    QLineEdit *lineEditUser;
    QPushButton *btnRegister;
    QLineEdit *lineEditPwd;
    QPushButton *btnCancel;

    void setupUi(QWidget *registerPage)
    {
        if (registerPage->objectName().isEmpty())
            registerPage->setObjectName(QString::fromUtf8("registerPage"));
        registerPage->resize(1440, 740);
        background = new QLabel(registerPage);
        background->setObjectName(QString::fromUtf8("background"));
        background->setGeometry(QRect(0, 0, 1440, 750));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        background->setFont(font);
        background->setPixmap(QPixmap(QString::fromUtf8(":/new/res/graph/4.jpg")));
        background->setScaledContents(true);
        lineEditUser = new QLineEdit(registerPage);
        lineEditUser->setObjectName(QString::fromUtf8("lineEditUser"));
        lineEditUser->setGeometry(QRect(900, 200, 480, 80));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lineEditUser->sizePolicy().hasHeightForWidth());
        lineEditUser->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font1.setPointSize(16);
        lineEditUser->setFont(font1);
        btnRegister = new QPushButton(registerPage);
        btnRegister->setObjectName(QString::fromUtf8("btnRegister"));
        btnRegister->setGeometry(QRect(970, 440, 150, 80));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(btnRegister->sizePolicy().hasHeightForWidth());
        btnRegister->setSizePolicy(sizePolicy1);
        btnRegister->setFont(font1);
        lineEditPwd = new QLineEdit(registerPage);
        lineEditPwd->setObjectName(QString::fromUtf8("lineEditPwd"));
        lineEditPwd->setGeometry(QRect(900, 330, 480, 80));
        sizePolicy.setHeightForWidth(lineEditPwd->sizePolicy().hasHeightForWidth());
        lineEditPwd->setSizePolicy(sizePolicy);
        lineEditPwd->setFont(font1);
        btnCancel = new QPushButton(registerPage);
        btnCancel->setObjectName(QString::fromUtf8("btnCancel"));
        btnCancel->setGeometry(QRect(1170, 440, 150, 80));
        sizePolicy1.setHeightForWidth(btnCancel->sizePolicy().hasHeightForWidth());
        btnCancel->setSizePolicy(sizePolicy1);
        btnCancel->setFont(font1);

        retranslateUi(registerPage);

        QMetaObject::connectSlotsByName(registerPage);
    } // setupUi

    void retranslateUi(QWidget *registerPage)
    {
        registerPage->setWindowTitle(QCoreApplication::translate("registerPage", "Form", nullptr));
        background->setText(QString());
        lineEditUser->setPlaceholderText(QCoreApplication::translate("registerPage", "\350\257\267\350\276\223\345\205\245\350\264\246\345\217\267", nullptr));
        btnRegister->setText(QCoreApplication::translate("registerPage", "\346\263\250\345\206\214", nullptr));
        lineEditPwd->setPlaceholderText(QCoreApplication::translate("registerPage", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", nullptr));
        btnCancel->setText(QCoreApplication::translate("registerPage", "\345\217\226\346\266\210", nullptr));
    } // retranslateUi

};

namespace Ui {
    class registerPage: public Ui_registerPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTERPAGE_H
