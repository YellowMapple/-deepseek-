/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../widget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Widget_t {
    QByteArrayData data[31];
    char stringdata0[512];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Widget"
QT_MOC_LITERAL(1, 7, 18), // "back_to_login_page"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 18), // "handleStateChanged"
QT_MOC_LITERAL(4, 46, 13), // "QAudio::State"
QT_MOC_LITERAL(5, 60, 5), // "state"
QT_MOC_LITERAL(6, 66, 13), // "readAudioData"
QT_MOC_LITERAL(7, 80, 22), // "onNetworkReplyFinished"
QT_MOC_LITERAL(8, 103, 10), // "speechNext"
QT_MOC_LITERAL(9, 114, 18), // "speechStateChanged"
QT_MOC_LITERAL(10, 133, 20), // "QTextToSpeech::State"
QT_MOC_LITERAL(11, 154, 15), // "requestDeepseek"
QT_MOC_LITERAL(12, 170, 14), // "handleCommands"
QT_MOC_LITERAL(13, 185, 14), // "switchFunction"
QT_MOC_LITERAL(14, 200, 4), // "flag"
QT_MOC_LITERAL(15, 205, 21), // "on_pushButton_pressed"
QT_MOC_LITERAL(16, 227, 22), // "on_pushButton_released"
QT_MOC_LITERAL(17, 250, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(18, 274, 28), // "on_pushButton_camera_clicked"
QT_MOC_LITERAL(19, 303, 12), // "enable_light"
QT_MOC_LITERAL(20, 316, 11), // "close_light"
QT_MOC_LITERAL(21, 328, 10), // "enable_fan"
QT_MOC_LITERAL(22, 339, 9), // "close_fan"
QT_MOC_LITERAL(23, 349, 13), // "enable_buzzer"
QT_MOC_LITERAL(24, 363, 12), // "close_buzzer"
QT_MOC_LITERAL(25, 376, 16), // "enable_shumaguan"
QT_MOC_LITERAL(26, 393, 15), // "close_shumaguan"
QT_MOC_LITERAL(27, 409, 20), // "enable_fan_low_speed"
QT_MOC_LITERAL(28, 430, 23), // "enable_fan_medium_speed"
QT_MOC_LITERAL(29, 454, 21), // "enable_fan_high_speed"
QT_MOC_LITERAL(30, 476, 35) // "on_pushButton_back_to_login_c..."

    },
    "Widget\0back_to_login_page\0\0"
    "handleStateChanged\0QAudio::State\0state\0"
    "readAudioData\0onNetworkReplyFinished\0"
    "speechNext\0speechStateChanged\0"
    "QTextToSpeech::State\0requestDeepseek\0"
    "handleCommands\0switchFunction\0flag\0"
    "on_pushButton_pressed\0on_pushButton_released\0"
    "on_pushButton_2_clicked\0"
    "on_pushButton_camera_clicked\0enable_light\0"
    "close_light\0enable_fan\0close_fan\0"
    "enable_buzzer\0close_buzzer\0enable_shumaguan\0"
    "close_shumaguan\0enable_fan_low_speed\0"
    "enable_fan_medium_speed\0enable_fan_high_speed\0"
    "on_pushButton_back_to_login_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  139,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    1,  140,    2, 0x08 /* Private */,
       6,    0,  143,    2, 0x08 /* Private */,
       7,    0,  144,    2, 0x08 /* Private */,
       8,    0,  145,    2, 0x08 /* Private */,
       9,    1,  146,    2, 0x08 /* Private */,
      11,    0,  149,    2, 0x08 /* Private */,
      12,    0,  150,    2, 0x08 /* Private */,
      13,    1,  151,    2, 0x08 /* Private */,
      15,    0,  154,    2, 0x08 /* Private */,
      16,    0,  155,    2, 0x08 /* Private */,
      17,    0,  156,    2, 0x08 /* Private */,
      18,    0,  157,    2, 0x08 /* Private */,
      19,    0,  158,    2, 0x08 /* Private */,
      20,    0,  159,    2, 0x08 /* Private */,
      21,    0,  160,    2, 0x08 /* Private */,
      22,    0,  161,    2, 0x08 /* Private */,
      23,    0,  162,    2, 0x08 /* Private */,
      24,    0,  163,    2, 0x08 /* Private */,
      25,    0,  164,    2, 0x08 /* Private */,
      26,    0,  165,    2, 0x08 /* Private */,
      27,    0,  166,    2, 0x08 /* Private */,
      28,    0,  167,    2, 0x08 /* Private */,
      29,    0,  168,    2, 0x08 /* Private */,
      30,    0,  169,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 10,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Widget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->back_to_login_page(); break;
        case 1: _t->handleStateChanged((*reinterpret_cast< QAudio::State(*)>(_a[1]))); break;
        case 2: _t->readAudioData(); break;
        case 3: _t->onNetworkReplyFinished(); break;
        case 4: _t->speechNext(); break;
        case 5: _t->speechStateChanged((*reinterpret_cast< QTextToSpeech::State(*)>(_a[1]))); break;
        case 6: _t->requestDeepseek(); break;
        case 7: _t->handleCommands(); break;
        case 8: _t->switchFunction((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_pushButton_pressed(); break;
        case 10: _t->on_pushButton_released(); break;
        case 11: _t->on_pushButton_2_clicked(); break;
        case 12: _t->on_pushButton_camera_clicked(); break;
        case 13: _t->enable_light(); break;
        case 14: _t->close_light(); break;
        case 15: _t->enable_fan(); break;
        case 16: _t->close_fan(); break;
        case 17: _t->enable_buzzer(); break;
        case 18: _t->close_buzzer(); break;
        case 19: _t->enable_shumaguan(); break;
        case 20: _t->close_shumaguan(); break;
        case 21: _t->enable_fan_low_speed(); break;
        case 22: _t->enable_fan_medium_speed(); break;
        case 23: _t->enable_fan_high_speed(); break;
        case 24: _t->on_pushButton_back_to_login_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAudio::State >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QTextToSpeech::State >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Widget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Widget::back_to_login_page)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Widget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Widget.data,
    qt_meta_data_Widget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
    return _id;
}

// SIGNAL 0
void Widget::back_to_login_page()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
