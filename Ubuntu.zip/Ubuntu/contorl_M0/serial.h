#ifndef _SERIAL_H
#define _SERIAL_H

struct env{
	int id;
	int tem;
	int hum;
	int light;
	int x;
	int y;
	int z;
};
struct env data;

int serial_init();
int serial_send(int fd, unsigned char *buf, int count);
int serial_recv(int fd, char *buf, int count,int len_buf);
int serial_exit(int fd);

#endif
