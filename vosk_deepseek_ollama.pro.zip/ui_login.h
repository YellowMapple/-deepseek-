/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_login
{
public:
    QLabel *background;
    QLineEdit *lineEditUser;
    QPushButton *btnLogin;
    QLineEdit *lineEditPwd;
    QPushButton *btnRegister;

    void setupUi(QWidget *login)
    {
        if (login->objectName().isEmpty())
            login->setObjectName(QString::fromUtf8("login"));
        login->resize(1440, 740);
        background = new QLabel(login);
        background->setObjectName(QString::fromUtf8("background"));
        background->setGeometry(QRect(0, 0, 1440, 750));
        QFont font;
        font.setKerning(false);
        background->setFont(font);
        background->setPixmap(QPixmap(QString::fromUtf8(":/new/res/graph/4.jpg")));
        background->setScaledContents(true);
        lineEditUser = new QLineEdit(login);
        lineEditUser->setObjectName(QString::fromUtf8("lineEditUser"));
        lineEditUser->setGeometry(QRect(900, 200, 480, 80));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lineEditUser->sizePolicy().hasHeightForWidth());
        lineEditUser->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font1.setPointSize(16);
        font1.setKerning(false);
        lineEditUser->setFont(font1);
        btnLogin = new QPushButton(login);
        btnLogin->setObjectName(QString::fromUtf8("btnLogin"));
        btnLogin->setGeometry(QRect(970, 440, 150, 80));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(btnLogin->sizePolicy().hasHeightForWidth());
        btnLogin->setSizePolicy(sizePolicy1);
        btnLogin->setFont(font1);
        lineEditPwd = new QLineEdit(login);
        lineEditPwd->setObjectName(QString::fromUtf8("lineEditPwd"));
        lineEditPwd->setGeometry(QRect(900, 330, 480, 80));
        sizePolicy.setHeightForWidth(lineEditPwd->sizePolicy().hasHeightForWidth());
        lineEditPwd->setSizePolicy(sizePolicy);
        lineEditPwd->setFont(font1);
        btnRegister = new QPushButton(login);
        btnRegister->setObjectName(QString::fromUtf8("btnRegister"));
        btnRegister->setGeometry(QRect(1170, 440, 150, 80));
        sizePolicy1.setHeightForWidth(btnRegister->sizePolicy().hasHeightForWidth());
        btnRegister->setSizePolicy(sizePolicy1);
        btnRegister->setFont(font1);

        retranslateUi(login);

        QMetaObject::connectSlotsByName(login);
    } // setupUi

    void retranslateUi(QWidget *login)
    {
        login->setWindowTitle(QCoreApplication::translate("login", "Form", nullptr));
        background->setText(QString());
        lineEditUser->setPlaceholderText(QCoreApplication::translate("login", "\350\257\267\350\276\223\345\205\245\350\264\246\345\217\267", nullptr));
        btnLogin->setText(QCoreApplication::translate("login", "\347\231\273\345\275\225", nullptr));
        lineEditPwd->setPlaceholderText(QCoreApplication::translate("login", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", nullptr));
        btnRegister->setText(QCoreApplication::translate("login", "\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class login: public Ui_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
