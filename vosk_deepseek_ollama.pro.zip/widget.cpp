#include "widget.h"
#include "ui_widget.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDebug>
#include <QRegularExpression>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    const char *modelPath = "D:/build-ui_vosk-Desktop_Qt_5_14_2_MinGW_64_bit-Debug/debug/models/vosk-model-small-cn-0.22";
    model = vosk_model_new(modelPath);
    if (!model) {
        qCritical() << "打开模型失败：" << modelPath;
        return ;
    }
    qDebug() << "加载模型成功";

    // 2. 创建识别器
    recognizer = vosk_recognizer_new(model, 16000.0);
    if (!recognizer) {
        qCritical() << "创建识别器失败";
        return ;
    }
    qDebug() << "识别器创建成功";

    format.setSampleRate(16000); // VOSK要求16kHz
    format.setChannelCount(1);   // 单声道
    format.setSampleSize(16);    // 16bit
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::SignedInt);


    QAudioDeviceInfo info = QAudioDeviceInfo::defaultInputDevice();
    if (!info.isFormatSupported(format)) {
        qWarning() << "Default format not supported, trying nearest...";
        format = info.nearestFormat(format);
    }

    audioInput = new QAudioInput(format);
    connect(audioInput, &QAudioInput::stateChanged, this, &Widget::handleStateChanged);

    httphelper = new QNetworkAccessManager;
    speech = new QTextToSpeech();
    speech->setRate(0.5);
    connect(speech, &QTextToSpeech::stateChanged, this, &Widget::speechStateChanged);


    //绑定socket
    // 对象空间分配
    socket01 = new QTcpSocket();

    //连接远程主机
    QString ip = QString("192.168.186.149");
    unsigned short port = 8888;

    socket01->connectToHost(ip,port);
//    qDebug()<<"成功与服务器连接！";
    //只调用一次connected
    connect(socket01,&QTcpSocket::connected,this,[]{
//        QMessageBox::about(this,"提示","连接成功！");
        qDebug()<<"控制端口成功与服务器连接！";
//        disconnect(socket01,&QTcpSocket::connected,this);
    });

    //控制跳转
    c = new camera();
//    back_to_mainwindow
    connect(c,&camera::back_to_mainwindow,this,&Widget::show);


    //绑定按钮
    connect(ui->pushButton_light_on,&QPushButton::clicked,this,&Widget::enable_light);
    connect(ui->pushButton_light_off,&QPushButton::clicked,this,&Widget::close_light);
    connect(ui->pushButton_4,&QPushButton::clicked,this,&Widget::enable_buzzer);
    connect(ui->pushButton_5,&QPushButton::clicked,this,&Widget::close_buzzer);
    connect(ui->pushButton_6,&QPushButton::clicked,this,&Widget::enable_fan);
    connect(ui->pushButton_7,&QPushButton::clicked,this,&Widget::enable_fan_low_speed);
    connect(ui->pushButton_8,&QPushButton::clicked,this,&Widget::enable_fan_medium_speed);
    connect(ui->pushButton_9,&QPushButton::clicked,this,&Widget::enable_fan_high_speed);
    connect(ui->pushButton_10,&QPushButton::clicked,this,&Widget::close_fan );
    connect(ui->pushButton_11,&QPushButton::clicked,this,&Widget::enable_shumaguan);
    connect(ui->pushButton_12,&QPushButton::clicked,this,&Widget::close_shumaguan);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::switchFunction(int flag){
    QString send_text = QString::number(flag);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
    // 打印 send_text 的内容
    qDebug() << "Sending text:" << send_text;
}

void Widget::handleCommands() {
    QString text = ui->textEdit_down->toPlainText();
//    ui->textEdit_down->toPlainText()
    qDebug()<<text;

    // 定义与各功能对应的正则表达式
    QRegularExpression lightOnRegex("light_on|开灯");
    QRegularExpression lightOffRegex("light_off|关灯");
    QRegularExpression buzzerOnRegex("buzzer_on|开蜂鸣器");
    QRegularExpression buzzerOffRegex("buzzer_off|关蜂鸣器");
    QRegularExpression fanOnRegex("fan_on|开风扇");
    QRegularExpression fanLowSpeedRegex("fan_low_speed|风扇低速");
    QRegularExpression fanMediumSpeedRegex("fan_medium_speed|风扇中速");
    QRegularExpression fanHighSpeedRegex("fan_high_speed|风扇高速");
    QRegularExpression fanOffRegex("fan_off|关风扇");
    QRegularExpression digitalTubeOnRegex("digital_tube_on|开数码管");
    QRegularExpression digitalTubeOffRegex("digital_tube_off|关数码管");

    // 假设 switchFunction(int code) 函数已经定义好，用于执行不同的硬件控制指令

    // 检查输入文本并执行相应的操作
    if (lightOnRegex.match(text).hasMatch()) {
        switchFunction(0); // 开启灯光
    } else if (lightOffRegex.match(text).hasMatch()) {
        switchFunction(1); // 关闭灯光
    } else if (buzzerOnRegex.match(text).hasMatch()) {
        switchFunction(2); // 开启蜂鸣器
    } else if (buzzerOffRegex.match(text).hasMatch()) {
        switchFunction(3); // 关闭蜂鸣器
    } else if (fanOnRegex.match(text).hasMatch()) {
        switchFunction(4); // 开启风扇
    } else if (fanLowSpeedRegex.match(text).hasMatch()) {
        switchFunction(5); // 风扇低速
    } else if (fanMediumSpeedRegex.match(text).hasMatch()) {
        switchFunction(6); // 风扇中速
    } else if (fanHighSpeedRegex.match(text).hasMatch()) {
        switchFunction(7); // 风扇高速
    } else if (fanOffRegex.match(text).hasMatch()) {
        switchFunction(8); // 关闭风扇
    } else if (digitalTubeOnRegex.match(text).hasMatch()) {
        switchFunction(9); // 开启数码管
    } else if (digitalTubeOffRegex.match(text).hasMatch()) {
        switchFunction(10); // 关闭数码管
    }
}


void Widget::onNetworkReplyFinished()
{

    while(reply->canReadLine())
    {
        QByteArray buf = reply->readLine();

        QJsonDocument doc = QJsonDocument::fromJson(buf);
        QJsonObject obj = doc.object();
        QString answer = obj.value("message").toObject().value("content").toString();
        if(answer.contains("</think>")){
            flag = 1;
            return;
        }

        if(flag)
        {

            buffer += answer;

            if(buffer.length() >= maxBufferSize || buffer.contains(QRegularExpression("[，。！？]"))){

                textQueue.append(buffer);
                    buffer.clear();
                if(speech->state() != QTextToSpeech::Speaking)
                    speechNext();
            }
//            handleCommands(buffer); // 处理命令
//            qDebug() << "text:" << answer;
            ui->textEdit_down->moveCursor(QTextCursor::End);
            ui->textEdit_down->insertPlainText(answer);
            ui->textEdit_down->ensureCursorVisible();
            QCoreApplication::processEvents();
        }
    }
    handleCommands(); // 处理命令
}

void Widget::speechNext()
{
    if(!textQueue.isEmpty()){
        QString text = textQueue.dequeue();
        speech->say(text);
    }
}

void Widget::speechStateChanged(QTextToSpeech::State state)
{
    if (state == QTextToSpeech::Ready && !textQueue.isEmpty()) {
        speechNext();
    }
}

void Widget::handleStateChanged(QAudio::State state)
{
    if (state == QAudio::StoppedState && audioInput->error() != QAudio::NoError) {
        qCritical() << "Audio input error:" << audioInput->error();
    }
}

void Widget::readAudioData()
{
    audioData.append(audioDevice->readAll());
}


void Widget::on_pushButton_pressed()
{
    audioData.clear();
    audioDevice = audioInput->start();
    connect(audioDevice, &QIODevice::readyRead, this, &Widget::readAudioData);

    ui->pushButton->setText("录音中");
}

void Widget::on_pushButton_released()
{
    audioInput->stop();
    disconnect(audioDevice, &QIODevice::readyRead, this, &Widget::readAudioData);

    if (!audioData.isEmpty()) {
        vosk_recognizer_accept_waveform(recognizer, audioData.constData(), audioData.size());
        const char *finalResultJson = vosk_recognizer_final_result(recognizer);
        //解析 JSON 并提取文本
        QJsonDocument doc =QJsonDocument::fromJson(finalResultJson);
        QJsonObject obj= doc.object();
        QStringList list = obj.value("text").toString().split(" ");//去掉识别到的文本里的空格
        QString vosktext= list.join("");//把所有的字符串放在一起显示//将识别到的文本放到 QTextEdit 中

        ui->textEdit_up->setText(vosktext);
        requestDeepseek();
    }
    ui->pushButton->setText("录音");
}

void Widget::requestDeepseek()
{
    QNetworkRequest _quest;
    _quest.setUrl((QUrl("http://127.0.0.1:11434/api/chat")));
    _quest.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    QJsonDocument document;
    QJsonObject obj;
    obj.insert("model","deepseek-r1:7b");

    QJsonObject obj1;
    obj1.insert("role","system");
//    obj1.insert("content","你是一个智能家居的高级管家，你的功能只有下面几个：开灯(light_on)、关灯(light_off)、开风扇(fan_on)、关风扇(fan_off)、开蜂鸣器(buzzer_on)、关蜂鸣器(buzzer_off)、以及自由聊天,"
//                          "根据用户的描述，请根据思考然后根据用户给你的描述直接给用户回复对应的命令。"
//                          "例如，用户给出:'请把灯打开',你需要思考之后回复:light_on");
    obj1.insert("content","你是一个智能家居的高级管家，你的功能包括开灯(light_on)、关灯(light_off)、开风扇(fan_on)、风扇低速(fan_low_speed)、风扇中速(fan_medium_speed)、风扇高速(fan_high_speed)、关风扇(fan_off)、开蜂鸣器(buzzer_on)、关蜂鸣器(buzzer_off)、开数码管(digital_tube_on)、关数码管(digital_tube_off)，以及自由聊天，根据用户的描述，请仔细思考然后直接回复对应的命令，例如用户给出:'请把灯打开',你需要思考之后回复:light_on。");
    QJsonObject obj2;
    obj2.insert("role","user");
    obj2.insert("content",ui->textEdit_up->toPlainText());


    QJsonArray arr;
    arr.append(obj1);//加入system人设
    arr.append(obj2);//加入问题
    obj.insert("messages", arr);

    obj.insert("stream",true);
    document.setObject(obj);
    QByteArray _postData = document.toJson(QJsonDocument::Compact);//以Json字符串的方式传参
    reply = httphelper->post(_quest,_postData);

    flag=0;
    ui->textEdit_down->clear();
    connect(reply, &QNetworkReply::readyRead, this, &Widget::onNetworkReplyFinished);
//    handleCommands(); // 处理命令

}

void Widget::on_pushButton_2_clicked()
{
    QNetworkRequest _quest;
    _quest.setUrl((QUrl("http://127.0.0.1:11434/api/chat")));
    _quest.setHeader(QNetworkRequest::ContentTypeHeader,"application/json");
    QJsonDocument document;
    QJsonObject obj;
    obj.insert("model","deepseek-r1:7b");

    QJsonObject obj1;
    obj1.insert("role","system");
//    obj1.insert("content","你是一个智能家居的高级管家，你的功能只有下面几个：开灯(light_on)、关灯(light_off)、开风扇(fan_on)、关风扇(fan_off)、开蜂鸣器(buzzer_on)、关蜂鸣器(buzzer_off)、以及自由聊天,"
//                          "根据用户的描述，请根据思考然后根据用户给你的描述直接给用户回复对应的命令。"
//                          "例如，用户给出:'请把灯打开',你需要思考之后回复:light_on");
    obj1.insert("content","你是一个智能家居的高级管家，你的功能包括开灯(light_on)、关灯(light_off)、开风扇(fan_on)、风扇低速(fan_low_speed)、风扇中速(fan_medium_speed)、风扇高速(fan_high_speed)、关风扇(fan_off)、开蜂鸣器(buzzer_on)、关蜂鸣器(buzzer_off)、开数码管(digital_tube_on)、关数码管(digital_tube_off)，以及自由聊天，根据用户的描述，请仔细思考然后直接回复对应的命令，例如用户给出:'请把灯打开',你需要思考之后回复:light_on。");
    QJsonObject obj2;
    obj2.insert("role","user");
    obj2.insert("content",ui->textEdit_up->toPlainText());


    QJsonArray arr;
    arr.append(obj1);//加入system人设
    arr.append(obj2);//加入问题
    obj.insert("messages", arr);

    obj.insert("stream",true);
    document.setObject(obj);
    QByteArray _postData = document.toJson(QJsonDocument::Compact);//以Json字符串的方式传参
    reply = httphelper->post(_quest,_postData);

    flag=0;
    ui->textEdit_down->clear();
    connect(reply, &QNetworkReply::readyRead, this, &Widget::onNetworkReplyFinished);
//    handleCommands(); // 处理命令
}

void Widget::on_pushButton_camera_clicked()
{
    //跳转到camera:pushButton_camera
    this->hide();
    c->show();
}


void Widget::enable_light(){
    QString send_text = QString::number(0);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::close_light(){
    QString send_text = QString::number(1);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::enable_buzzer(){
    QString send_text = QString::number(2);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::close_buzzer(){
    QString send_text = QString::number(3);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::enable_fan(){
    QString send_text = QString::number(4);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}

void Widget::enable_fan_low_speed(){
    QString send_text = QString::number(5);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::enable_fan_medium_speed(){
    QString send_text = QString::number(6);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::enable_fan_high_speed(){
    QString send_text = QString::number(7);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::close_fan(){
    QString send_text = QString::number(8);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}

void Widget::enable_shumaguan(){
    QString send_text = QString::number(9);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}
void Widget::close_shumaguan(){
    QString send_text = QString::number(10);
    QByteArray send_message = send_text.toLatin1();
    socket01->write(send_message);
}

void Widget::on_pushButton_back_to_login_clicked()
{
    //转到登录页面
    this->hide();
    emit back_to_login_page();
}
