#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <registerPage.h>
#include <widget.h>
#include <camera.h>

namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

//signals:
//    void sigLogin();


private slots:
    void on_btnLogin_clicked();

    void on_btnRegister_clicked();

private:
    Ui::login *ui;
    registerPage *reg;
    Widget *wid;
    camera *c;
};

#endif // LOGIN_H
