#ifndef REGISTER_H
#define REGISTER_H

#include <QWidget>

namespace Ui {
class registerPage;
}

class registerPage : public QWidget
{
    Q_OBJECT

public:
    explicit registerPage(QWidget *parent = nullptr);
    ~registerPage();
signals:
    void back_to_login();

private slots:
    void on_btnRegister_clicked();

private:
    Ui::registerPage *ui;
};


#endif // REGISTER_H
