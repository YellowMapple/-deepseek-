#include "login.h"
#include "ui_login.h"

#include "cglobaldata.h"

#include <QSqlQuery>

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    reg = new registerPage;
    wid = new Widget;
    c = new camera;
    connect(c,&camera::back_to_login,this,&login::show);//摄像头和环境
    connect(wid,&Widget::back_to_login_page,this,&login::show);//控制
    connect(reg,&registerPage::back_to_login,this,&login::show);//注册
}

login::~login()
{
    delete ui;
}

void login::on_btnLogin_clicked()
{
    QString user = ui->lineEditUser->text().trimmed();
    QString pwd = ui->lineEditPwd->text().trimmed();
    if(user.isEmpty() || user.isEmpty()) {
        QMessageBox::information(this, u8"提示", u8"账号或密码为空");
        qDebug() << u8"账号或密码为空";
        return;
    }
//    qDebug()<<user;
//    qDebug()<<pwd;
    if(CGlobalData::getInstance().judgeUserInfo(user, pwd)) {
        qDebug() << u8"登录成功";
        this->hide();
        wid->show();
    }
    else {
        QMessageBox::information(this, u8"提示", u8"用户不存在（请注册）或密码错误");
    }
}

void login::on_btnRegister_clicked()
{
    //这里是跳转去注册页面
//    FormRegister *formRegister = new FormRegister;
//    formRegister->show();
    this->hide();
    reg->show();
}
