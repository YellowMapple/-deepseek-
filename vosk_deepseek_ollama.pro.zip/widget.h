#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QAudioFormat>
#include <QAudioInput>
#include <QAudioDeviceInfo>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QTextToSpeech>
#include <QQueue>
#include <QTcpSocket>
#include "vosk_api.h"
#include "camera.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

signals:
    void back_to_login_page();

private slots:
    void handleStateChanged(QAudio::State state);
    void readAudioData();
    void onNetworkReplyFinished();
    void speechNext();
    void speechStateChanged(QTextToSpeech::State state);
    void requestDeepseek();
    void handleCommands();
    void switchFunction(int flag);

    void on_pushButton_pressed();

    void on_pushButton_released();

    void on_pushButton_2_clicked();

    void on_pushButton_camera_clicked();

    void enable_light();
    void close_light();
    void enable_fan();
    void close_fan();
    void enable_buzzer();
    void close_buzzer();
    void enable_shumaguan();
    void close_shumaguan();
    void enable_fan_low_speed();
    void enable_fan_medium_speed();
    void enable_fan_high_speed();


    void on_pushButton_back_to_login_clicked();

private:
    Ui::Widget *ui;
    VoskModel *model;
    VoskRecognizer *recognizer;
    QAudioInput *audioInput;
    QAudioFormat format;
    QIODevice *audioDevice;
    QByteArray audioData;
    QNetworkAccessManager *httphelper;
    QNetworkReply *reply;
    QTextToSpeech *speech;
    QQueue<QString> textQueue;
    QString buffer;
    QTcpSocket *socket01;
    camera *c;

    int maxBufferSize = 50;
    int flag =0;
};
#endif // WIDGET_H
