#include "registerPage.h"
#include "ui_registerPage.h"
#include <QSqlQuery>
#include "cglobaldata.h"

registerPage::registerPage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::registerPage)
{
    ui->setupUi(this);
    setWindowModality(Qt::ApplicationModal);
    setAttribute(Qt::WA_DeleteOnClose, true);
    connect(ui->btnCancel, &QPushButton::clicked, this, &QWidget::close);
}

registerPage::~registerPage()
{
delete ui;
}

void registerPage::on_btnRegister_clicked()
{
    QString user = ui->lineEditUser->text().trimmed();
    QString pwd = ui->lineEditPwd->text().trimmed();
    if(user.isEmpty() || user.isEmpty()) {
        QMessageBox::information(this, u8"提示", u8"账号或密码为空");
        return;
    }

    if(CGlobalData::getInstance().judgeUserExist(user)) {
        QMessageBox::information(this, u8"提示", u8"账号已存在！请更新账号");
        return;
    }

    if(CGlobalData::getInstance().insertUserData(user, pwd)) {
        this->hide();
        emit back_to_login();
    }
}
