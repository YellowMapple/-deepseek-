#ifndef CONN_SERVER_H
#define CONN_SERVER_H

#include <QWidget>

namespace Ui {
class conn_server;
}

class conn_server : public QWidget
{
    Q_OBJECT

public:
    explicit conn_server(QWidget *parent = nullptr);
    ~conn_server();

private slots:
    void on_pushButton_clicked();

private:
    Ui::conn_server *ui;
    QTcpSocket *socket01;
};

#endif // CONN_SERVER_H
