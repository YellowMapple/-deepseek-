#include "v4l2.h"
#include <pthread.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/select.h>

// 全局变量
static int g_running = 1;
static int g_camera_fd;
static int g_socket_fd;
static struct sockaddr_in g_server_addr;    // 改为服务器地址
static struct sockaddr_in g_client_addr;
static int g_client_connected = 0;          // 添加客户端连接状态标志

// 视频参数结构体
typedef struct {
    unsigned int width;
    unsigned int height;
    unsigned int format;  // 0: YUYV, 1: MJPEG
    unsigned int fps;     // 实际帧率
} video_params_t;

static video_params_t g_video_params = {
    .width = 640,
    .height = 480,
    .format = 0,
    .fps = 30
};

// 信号处理函数
void signal_handler(int signo)
{
    if(signo == SIGINT) {
        printf("\nReceived SIGINT, cleaning up...\n");
        g_running = 0;
    }
}

// 摄像头处理线程
void* camera_thread(void *arg)
{
    void *buffer;
    unsigned int pic_size;
    unsigned int index;
    struct timespec start, end;
    unsigned int frame_count = 0;
    double elapsed_time;
    socklen_t addr_len = sizeof(g_client_addr);
    char client_msg[32];
    
    clock_gettime(CLOCK_MONOTONIC, &start);
    
    while(g_running) {
        // 等待客户端连接请求
        if (!g_client_connected) {
            struct timeval tv;
            tv.tv_sec = 0;
            tv.tv_usec = 100000;  // 100ms超时
            
            fd_set readfds;
            FD_ZERO(&readfds);
            FD_SET(g_socket_fd, &readfds);
            
            int ret = select(g_socket_fd + 1, &readfds, NULL, NULL, &tv);
            if (ret < 0 && g_running == 0) {  // 检查是否因为信号中断
                break;
            }
            if (ret > 0 && FD_ISSET(g_socket_fd, &readfds)) {
                int recv_len = recvfrom(g_socket_fd, client_msg, sizeof(client_msg), 0,
                                      (struct sockaddr*)&g_client_addr, &addr_len);
                if (recv_len > 0) {
                    printf("Client connected from %s:%d\n", 
                           inet_ntoa(g_client_addr.sin_addr),
                           ntohs(g_client_addr.sin_port));
                    g_client_connected = 1;
                }
            }
            continue;
        }

        // 获取一帧图像
        if(camera_debuf(g_camera_fd, &buffer, &pic_size, &index) < 0) {  // 修改判断条件
            if (!g_running) break;  // 如果是因为信号退出，则跳出循环
            continue;  // 如果是其他错误，继续尝试
        }

        // 打印图像信息
        printf("Frame size: %d bytes, Format: %s, Resolution: %dx%d, FPS: %d\n",
               pic_size,
               g_video_params.format ? "MJPEG" : "YUYV",
               g_video_params.width,
               g_video_params.height,
               g_video_params.fps);

        // 发送视频参数和图像数据到已连接的客户端
        sendto(g_socket_fd, &g_video_params, sizeof(video_params_t), 0, 
              (struct sockaddr*)&g_client_addr, sizeof(g_client_addr));
        sendto(g_socket_fd, buffer, pic_size, 0, 
              (struct sockaddr*)&g_client_addr, sizeof(g_client_addr));
        
        // 将缓冲区放回队列
        camera_eqbuf(g_camera_fd, index);
        
        // 计算实际帧率
        frame_count++;
        if(frame_count == 30) {
            clock_gettime(CLOCK_MONOTONIC, &end);
            elapsed_time = (end.tv_sec - start.tv_sec) + 
                         (end.tv_nsec - start.tv_nsec) / 1000000000.0;
            g_video_params.fps = (unsigned int)(frame_count / elapsed_time);
            
            // 重置计数器
            frame_count = 0;
            start = end;
        }

        if (!g_running) break;  // 在处理完当前帧后检查是否需要退出
    }
    return NULL;
}

int main(int argc, char *argv[])
{
    pthread_t camera_tid;
    unsigned int size;
    unsigned int ismjpeg;
    
    // 设置信号处理
    signal(SIGINT, signal_handler);
    
    // 初始化摄像头
    g_camera_fd = camera_init("/dev/video0", 
                            &g_video_params.width, 
                            &g_video_params.height, 
                            &size, 
                            &ismjpeg);
    if(g_camera_fd < 0) {
        printf("Failed to initialize camera\n");
        return -1;
    }
    g_video_params.format = ismjpeg;
    printf("Camera initialized: %dx%d, %s\n", 
           g_video_params.width, g_video_params.height, 
           ismjpeg ? "MJPEG" : "YUYV");
    
    // 启动摄像头
    if(camera_start(g_camera_fd) < 0) {
        printf("Failed to start camera\n");
        camera_exit(g_camera_fd);
        return -1;
    }
    printf("Camera started successfully\n");
    
    // 初始化网络（服务器模式）
    g_socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(g_socket_fd < 0) {
        printf("Failed to create socket\n");
        camera_stop(g_camera_fd);
        camera_exit(g_camera_fd);
        return -1;
    }
    
    // 设置服务器地址
    memset(&g_server_addr, 0, sizeof(g_server_addr));
    g_server_addr.sin_family = AF_INET;
    g_server_addr.sin_port = htons(8080);
    g_server_addr.sin_addr.s_addr = htonl(INADDR_ANY);  // 监听所有网络接口

    // 绑定服务器地址
    if (bind(g_socket_fd, (struct sockaddr*)&g_server_addr, sizeof(g_server_addr)) < 0) {
        printf("Failed to bind socket\n");
        close(g_socket_fd);
        camera_stop(g_camera_fd);
        camera_exit(g_camera_fd);
        return -1;
    }
    
    printf("Server listening on port 8080...\n");
    
    // 创建摄像头处理线程
    if(pthread_create(&camera_tid, NULL, camera_thread, NULL) != 0) {
        printf("Failed to create camera thread\n");
        camera_stop(g_camera_fd);
        camera_exit(g_camera_fd);
        close(g_socket_fd);
        return -1;
    }
    
    // 等待中断信号
    while(g_running) {
        sleep(1);
    }
    
    printf("\nShutting down...\n");
    
    // 等待线程结束
    pthread_join(camera_tid, NULL);
    
    // 清理资源
    camera_stop(g_camera_fd);
    camera_exit(g_camera_fd);
    close(g_socket_fd);
    
    printf("Cleanup complete\n");
    return 0;
} 
